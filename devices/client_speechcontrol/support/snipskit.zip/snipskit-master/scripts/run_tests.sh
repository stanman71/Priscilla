#!/bin/sh
pytest --cov src --verbose
