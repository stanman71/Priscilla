#!/bin/sh
cd docs && make html
