"""This module contains classes to create components that communicate with
Snips services using the MQTT protocol directly.
"""
