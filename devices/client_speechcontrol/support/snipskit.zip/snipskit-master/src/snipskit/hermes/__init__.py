"""This module contains classes to create components that communicate with
Snips services using the Hermes Python library.
"""
