#######
License
#######

SnipsKit is distributed published under the following license:

.. include:: ../../LICENSE
