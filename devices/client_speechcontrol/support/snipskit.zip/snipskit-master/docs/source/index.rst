########
SnipsKit
########

Welcome to SnipsKit's documentation.

.. include:: ../../README.rst
   :start-after: inclusion-marker-start-intro
   :end-before: inclusion-marker-end-intro

********
Contents
********

.. toctree::
   :maxdepth: 2

   installation
   usage
   API
   development
   LICENSE
   CHANGELOG

******************
Indices and tables
******************

- :ref:`genindex`
- :ref:`modindex`
