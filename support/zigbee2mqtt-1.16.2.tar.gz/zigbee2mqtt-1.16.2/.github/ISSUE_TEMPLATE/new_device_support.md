---
name: New device support request
about: Request support for a new device
title: ''
labels: new device support
assignees: ''

---

<!--
IMPORTANT: Before submitting a request, first follow: https://www.zigbee2mqtt.io/how_tos/how_to_support_new_devices.html
-->

## Information about the device + link
..

## data/database.db entry of the device
..
