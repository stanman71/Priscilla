WSGI Application Profiler
=========================

.. warning::
    ``werkzeug.contrib.profiler`` has moved to
    :mod:`werkzeug.middleware.profile`. The old import is deprecated as
    of version 0.15 and will be removed in version 1.0.

.. autoclass:: werkzeug.contrib.profiler.MergeStream
