Lint Validation Middleware
==========================

.. warning::
    ``werkzeug.contrib.lint`` has moved to
    :mod:`werkzeug.middleware.lint`. The old import is deprecated as of
    version 0.15 and will be removed in version 1.0.
