================
Atom Syndication
================

.. warning::
    .. deprecated:: 0.15
        This will be removed in version 1.0. Use a dedicated feed
        library instead.

.. automodule:: werkzeug.contrib.atom

.. autoclass:: AtomFeed
   :members:

.. autoclass:: FeedEntry
