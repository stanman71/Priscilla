"""
This code provides the ability to run fabric
package as a script
Usage: python -m fabric
"""

from .main import program

program.run()
