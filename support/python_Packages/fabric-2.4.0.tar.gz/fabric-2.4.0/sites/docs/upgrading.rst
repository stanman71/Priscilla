:orphan:

==================
Upgrading - moved!
==================

If you're here, you're probably following an old link or bookmark. The
upgrading page has moved to the unversioned main project site:
:ref:`upgrading`. Please update your bookmarks and links!
