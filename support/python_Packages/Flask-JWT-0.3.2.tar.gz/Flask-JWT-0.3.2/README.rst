Flask-JWT
==============

.. image:: https://img.shields.io/travis/mattupstate/flask-jwt.svg
    :target: https://travis-ci.org/mattupstate/flask-jwt
    :alt: Latest Build

.. image:: https://img.shields.io/pypi/v/flask-jwt.svg
    :target: https://pypi.python.org/pypi/Flask-JWT/
    :alt: Latest Version

.. image:: https://img.shields.io/coveralls/mattupstate/flask-jwt.svg
    :target: https://coveralls.io/r/mattupstate/flask-jwt

.. image:: https://img.shields.io/pypi/dm/flask-jwt.svg
    :target: https://pypi.python.org/pypi//Flask-JWT/
    :alt: Downloads

.. image:: https://img.shields.io/pypi/l/flask-jwt.svg
    :target: https://pypi.python.org/pypi/Flask-JWT/
    :alt: License

JWT (JSON Web Tokens) for Flask applications


Resources
---------

- `Documentation <http://packages.python.org/Flask-JWT/>`_
- `Issue Tracker <http://github.com/mattupstate/flask-jwt/issues>`_
- `Code <http://github.com/mattupstate/flask-jwt/>`_
- `Development Version
  <http://github.com/mattupstate/flask-jwt/zipball/develop#egg=Flask-JWTy-dev>`_
