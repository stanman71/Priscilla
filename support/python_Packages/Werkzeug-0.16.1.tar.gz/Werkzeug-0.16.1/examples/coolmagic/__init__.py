# -*- coding: utf-8 -*-
"""
    coolmagic
    ~~~~~~~~~

    Package description goes here.

    :copyright: 2007 Pallets
    :license: BSD-3-Clause
"""
from .application import make_app
