.. include:: ../README.rst

.. toctree::
   :hidden:
   :name: mastertoc

   self
   api

