---
name: New device support request
about: Request support for a new device
title: ''
labels: new device support
assignees: ''

---

<!--
VERY IMPORTANT: Before submitting a request, first (try to) follow: https://www.zigbee2mqtt.io/how_tos/how_to_support_new_devices.html

Dumping just the info about this device without actually attemping adding support yourself will likely lead into this issue being ignored.
Clearly indicate what you tried and where you got stuck.
-->

## Information about the device + link
..

## data/database.db entry of the device
..
