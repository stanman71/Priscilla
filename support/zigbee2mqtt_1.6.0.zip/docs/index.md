Moved to [https://www.zigbee2mqtt.io](https://www.zigbee2mqtt.io)
